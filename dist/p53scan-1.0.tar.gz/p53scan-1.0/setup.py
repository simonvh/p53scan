from distutils.core import setup, Extension

DESCRIPTION  = """p53scan
An algorithm to find p53 binding sites.
Smeenk et al., manuscript in preparation."""

module1 = Extension('PftScan.core',
					sources = ['PftScan/coremodule.c'])

setup (name = 'p53scan',
		version = '1.0',
		description = DESCRIPTION,
		author='Simon van Heeringen',
		author_email='s.vanheeringen@ncmls.ru.nl',
		url='http://www.ncmls.nl/molbio/p53',
		license='MIT',
		ext_modules = [module1],
		packages=['PftScan'],
		scripts=['scripts/p53scan.py', 'scripts/p53scan_gui.py', 'scripts/windows_postinstall.py'],
)
